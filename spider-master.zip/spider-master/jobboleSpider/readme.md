对于这个爬虫的详解解释看我的个人博客：http://www.cnblogs.com/zhaof/p/7173094.html或者http://www.pythonsite.com/
