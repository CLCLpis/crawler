关于代码的解释在我的个人博客地址：
http://www.pythonsite.com/?p=307
http://www.pythonsite.com/?p=312
